/*
 * ATmega328P_Scheduler.c
 *
 * Created: 12/10/2019 01:51:06 a. m.
 * Author : Lalo
 */ 

#include <avr/io.h>
#include <os.h>

void Task1 (void);
void Task2 (void);
void Task3 (void);
void Task4 (void);



int main(void)
{
	GPIO__vInitPort();
	OS__enAddThreads(&Task1, &Task2, &Task3, &Task4);
	OS__vLaunch();


}


void Task1(void)
{
	while(1)
	{
		if((PIND & (1<<PIND2))==0)
			PORTC|=(1<<PORTC3);
		else
			PORTC&=~(1<<PORTC3);
		
	}
}

void Task2 (void)
{
	while(1)
	{
		if((PINB & (1<<PINB2))==0)
			PORTC|=(1<<PORTC4);
		else
			PORTC&=~(1<<PORTC4);
	}
}

void Task3 (void)
{
	while(1)
	{
		if((PINB & (1<<PINB1))==0)
			PORTC|=(1<<PORTC5);
		else
			PORTC&=~(1<<PORTC5);
	}
}

void Task4 (void)
{
	while(1)
	{
		PORTB^=(1<<PORTB5);
	}
}